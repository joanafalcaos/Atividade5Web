function calcularFatorial (numero) {
    if (numero === 0 || numero === 1) {
        return 1;
    }
    var fatorial = 1;

    for (var i = 2; i <= numero; i++) {
        fatorial *= i;
    }
    return fatorial;
}
// Retorno da função
console.log(calcularFatorial(0));
console.log(calcularFatorial(8));