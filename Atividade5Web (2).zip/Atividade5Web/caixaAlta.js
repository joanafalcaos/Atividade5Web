function caixaAlta(texto) {
    return texto.toUpperCase();
}
// Retorno da função
console.log(caixaAlta("Teste"));