function verificarPalindromo(palavra) {
    var palavraInvertida = palavra.split('').reverse().join('');
    return palavra === palavraInvertida
}
function converterBinario(numero) {
    return numero.toString(2);
}
// Verificar Palíndromo
console.long(verificarPalindromo("ama"));

// Converter para Binário
console.log(converterBinario(25));