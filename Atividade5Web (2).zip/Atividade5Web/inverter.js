function inverter(array) {
    return array.reverse();
}
// Retorno da função
var conjunto1 = [um, dois, três, quatro, cinco, seis];
console.log(inverter(conjunto1));

var conjunto2 = [1, 2, 3, 4, 5, 6];
console.log(inverter(conjunto2));