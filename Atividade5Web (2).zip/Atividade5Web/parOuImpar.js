function parOuImpar(numero) {
    if (numero % 2 == 0) {
        return true;
    } else {
        return false;
    }
}
console.log(parOuImpar(2)); // true
console.log(parOuImpar(3)); // false