function somarValorPorcent(valor, porcentagem) {
    var valorAcrescido = valor + (valor * porcentagem / 100);
    return valorAcrescido;
}
// Retorno da função
console.log(somarValorPorcent(50, 20));