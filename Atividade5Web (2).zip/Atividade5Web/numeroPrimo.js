function numeroPrimo(numero) {
    if (numero <=1) {
        return false;
    }
    for (var i = 2; i <= Math.sqrt(numero); i++) {
        if (numero % i === 0) {
            return false;
        }
    }
    return true;
}
// Retorno da função
console.log(numeroPrimo(7));
console.log(numeroPrimo(1));