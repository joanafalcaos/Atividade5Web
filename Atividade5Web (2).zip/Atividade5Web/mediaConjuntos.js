function mediaConjuntos() {
    if (numeros.length === 0) {
        return 0;
    }

// Soma de todos os números do array
var soma = numeros.reduce(function(acumulador, numero) {
    return acumulador + numero;
}, 0);

// Calculo da média dividindo a soma pelo número de elementos no array
var media = soma / numeros.length;
return media;
}

// Retorno da função
var conjunto1 = [5, 10, 20, 30];
console.log(mediaConjuntos(conjunto1));

var conjunto2 = [];
console.log(mediaConjuntos(conjunto2));