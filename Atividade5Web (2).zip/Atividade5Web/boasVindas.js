// Função de boas vindas
function boasVindas(){
    return "Bem-vindo!";
}

// Chamando a função
var mensagem = boasVindas();
console.log(mensagem);